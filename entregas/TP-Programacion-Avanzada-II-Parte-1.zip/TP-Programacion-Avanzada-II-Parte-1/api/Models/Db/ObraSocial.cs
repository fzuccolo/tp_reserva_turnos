namespace turnos.Models.Db;

public class ObraSocial
{
    public int ObraSocialId { get; set; }
    public string Nombre { get; set; } = string.Empty;
}