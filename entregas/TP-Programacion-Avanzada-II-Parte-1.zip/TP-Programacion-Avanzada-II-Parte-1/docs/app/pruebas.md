# Sitio con sus puntos de prueba

En esta sección se muestran los diferentes puntos de prueba del sitio.

## Imágenes Locales

![Inicio](imagen1.png)
![Listado de pacientes](imagen2.png)
![Alta de paciente](imagen3.png)
![Error en alta de paciente](imagen4.png)
![Acerca de](imagen5.png)