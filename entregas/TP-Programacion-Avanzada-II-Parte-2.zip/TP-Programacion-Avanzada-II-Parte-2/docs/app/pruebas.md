# Sitio con sus puntos de prueba

En esta sección se muestran los diferentes puntos de prueba del sitio.

## Imágenes Locales

Página única de la aplicación:

![Página única de la aplicacion](imagen1.png)
