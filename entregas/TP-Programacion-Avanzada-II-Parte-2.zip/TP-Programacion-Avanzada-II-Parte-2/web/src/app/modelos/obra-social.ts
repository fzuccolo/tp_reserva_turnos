export interface ObraSocial {
    id: number;
    nombre: string;
}