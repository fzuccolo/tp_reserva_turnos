export interface Sucursal {
    id: number;
    nombre: string;
    direccion: string;
}