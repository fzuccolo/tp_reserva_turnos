namespace turnos.Models.Api;

public class ObraSocialGetResponseModel
{
    public int ObraSocialId { get; set; }
    public string Nombre { get; set; } = string.Empty;
}